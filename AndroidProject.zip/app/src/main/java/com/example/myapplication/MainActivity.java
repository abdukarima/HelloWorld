package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txt;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt = (TextView) findViewById(R.id.mytext);
        btn = (Button) findViewById(R.id.mybutton);

        btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                txt.setText("Avazi Abdukarim");
            }
        });
    }
}
